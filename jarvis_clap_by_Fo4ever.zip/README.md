# Jarvis Clap - Arduino Firmware 👏

Arduino sketch that detects sound/claps, reads temperature and humidity via DHT11, plays a buzzer confirmation tone, and sends serial trigger data (`CLAP|<temperature>|<humidity>`) over USB.

---

## 🔌 Hardware Setup

- **Arduino Uno / Nano**
- **Sound Sensor Module** (digital pin `DO` connected to `D4`, `VCC` to `D5`, `GND` to `D6`)
- **DHT11 Sensor** (`DATA` connected to `A2`)
- **Piezo Buzzer** (`+` connected to `D9`, `-` to `GND`)

## 📦 Required Libraries
- **DHT sensor library** (Adafruit)
- **Adafruit Unified Sensor**

## 🚀 How to Use
1. Open [`jarvis_clap.ino`](jarvis_clap.ino) in Arduino IDE.
2. Select your board model and COM port.
3. Upload to the board.
4. Open the Serial Monitor at **9600 baud** or run the companion Python script to receive triggers.

---

## 🛡 License
MIT License
